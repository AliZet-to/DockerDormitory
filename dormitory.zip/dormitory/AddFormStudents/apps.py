from django.apps import AppConfig


class AddformstudentsConfig(AppConfig):
    name = 'AddFormStudents'
