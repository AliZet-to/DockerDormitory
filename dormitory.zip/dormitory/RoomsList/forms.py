from django import forms


class RoomsForm(forms.Form):
    num_room = forms.IntegerField(min_value=1, max_value=100)
    num_build = forms.IntegerField()
    count_places = forms.IntegerField()
    count_resident = forms.IntegerField()
