from django.shortcuts import render
from django.http import HttpResponseRedirect
from RoomsList.models import Rooms
from RoomsList.forms import RoomsForm
from django.views.generic import View
from .utilites import ViewObjectMixin


def Show_room(request):
    name = 'Sasha'
    obj01 = Rooms.objects.all()
    # return render(request, 'RoomsList/index_old.html', context={'num_room': obj01.num_room,
    #                                                         'num_build': obj01.num_build,
    #                                                         'count_places': obj01.count_places,
    #                                                         'count_resident': obj01.count_resident})
    return render(request, 'RoomsList/index.html', context={'rooms': obj01})
    # return render(request, 'base.html', context={'rooms': obj01})

# def rooms_detail(request, slug):
#     room = Rooms.objects.get(slug = slug)
#     print()
#     print('hiii')
#     print(dir(request))
#     return render(request, 'RoomsList/room.html', context={'room': room})

# class Rooms_details(View):
#     def get(self, request, slug):
#         room = Rooms.objects.get(slug = slug)
#         return render(request, 'RoomsList/room.html', context={'room': room})


class Rooms_details(ViewObjectMixin, View):
    model = Rooms
    template = 'RoomsList/room.html'


def enter_room(request):
     form = RoomsForm()
     return render(request, 'RoomsList/room_form.html', context={'form': form})

def create_room(request):
    print()
    print('hiii')
    print()
    if request.method == 'POST':
        room = Rooms()
        room.num_room = request.POST.get("num_room")
        room.num_build = request.POST.get("num_build")
        room.count_places = request.POST.get("count_places")
        room.count_resident = request.POST.get("count_resident")
        room.slug = str(room.num_room) + '_' + str(room.num_build)
        room.save()
    return HttpResponseRedirect('/RoomsList/')

def edit_room(request, slug):
    obj = Rooms.objects.get(slug=slug)
    form = RoomsForm(initial={'num_room': obj.num_room,
                              'num_build': obj.num_build,
                              'count_places': obj.count_places,
                              'count_resident': obj.count_resident})
    return render(request, 'RoomsList/room_form.html', context={'form': form})