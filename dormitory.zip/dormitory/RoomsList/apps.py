from django.apps import AppConfig


class RoomslistConfig(AppConfig):
    name = 'RoomsList'
