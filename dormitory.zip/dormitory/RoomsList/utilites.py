from  django.shortcuts import render


class ViewObjectMixin:
    model = None
    template = None
    def get(self, request, slug):
        obj = self.model.objects.get(slug=slug)
        return render(request, self.template, context={self.model.__name__.lower(): obj})