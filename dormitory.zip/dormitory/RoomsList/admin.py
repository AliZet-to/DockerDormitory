from django.contrib import admin
from RoomsList.models import Rooms


admin.site.register(Rooms)