from django.apps import AppConfig


class DormsConfig(AppConfig):
    name = 'Dorms'
