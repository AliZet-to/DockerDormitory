from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth import login, logout, authenticate


def RegView(request):
    form = UserCreationForm(request.POST)
    return render(request, 'AuthAndReg/reg.html', context={'form': form})

def RegCreate(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/RoomsList/')
        else:
            return HttpResponseRedirect('/register/')
    else:
        return HttpResponseRedirect('/register/')

def LogView(request):
    form = AuthenticationForm()
    return render(request, 'AuthAndReg/log.html', context={'form': form})

def LogEnter(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/RoomsList/')
        else:
            return HttpResponseRedirect('/login/')
    else:
        return HttpResponseRedirect('/login/')

def HomeView(request):
    return render(request, 'AuthAndReg/home.html')

def LogoutView(request):
    if request.method == 'POST':
        logout(request)
        return redirect('http://127.0.0.1:8000/login/')
    else:
        return redirect('http://127.0.0.1:8000/home/')