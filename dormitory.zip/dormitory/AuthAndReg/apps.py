from django.apps import AppConfig


class AuthandregConfig(AppConfig):
    name = 'AuthAndReg'
