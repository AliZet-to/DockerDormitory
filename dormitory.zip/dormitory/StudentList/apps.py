from django.apps import AppConfig


class StudentlistConfig(AppConfig):
    name = 'StudentList'
