from django.contrib import admin
from StudentList.models import Students


admin.site.register(Students)