from django.apps import AppConfig


class FullinfostudentsConfig(AppConfig):
    name = 'FullInfoStudents'
